package me.dio.sacola;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SacolaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
